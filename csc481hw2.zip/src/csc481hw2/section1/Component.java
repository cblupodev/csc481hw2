package csc481hw2.section1;

// just a marker interface to basically tag a class as component

public interface Component {

}
