package csc481hw2.section1;

// just a marker interface to tag something as a game object

public interface GameObject {
	
}