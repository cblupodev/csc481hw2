I included a screencast of the section3 code running in demo.mp4

- These instructions are for Windows
- The subdirectories are in "src\csc481hw2"
- Import the csc481hw2 folder in Eclipse

# Section 2
- run "Server.java" as a java application
- open three cmd.exe terminals and make working directory the folder you extracted the files to
- in each terminal run this command:
   java -jar Client2.jar 127.0.0.1
   
# Section 3
- Exact same instructions as Section to except run Client3.jar
- Every once in a while when you run the third Client3.jar application it will crap out and hang. 
  I know the line that causes the problem but I can't figure out why that is happening. 
  If you kill all applications and run everything again (including the server)
  eventually the third  Client3.jar will work 